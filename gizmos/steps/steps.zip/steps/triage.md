# TRIAGE — Steps
Split per the dictation: the sequencer is the pure gizmo (mod float in →
note/trig/step out, pentatonic, tempo-stepped on the reader's t); the voice
is the lane's speaker for now — WebAudio is a Sink, like the canvas, so the
gizmo stays pure and portable. The proper Numpty synth gizmo waits on the
audio port-type ruling (flagged with the instruments brief). Words drive it
today: Prose.rhythm -> Steps.mod. Images can too: Glyph.ink -> Steps.mod.
