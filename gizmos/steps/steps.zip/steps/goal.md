# GOAL — Steps
1. pure sequencer in the reader (note/trig/step from params + mod + t);
2. Prose rhythm audibly steering the melody on the site, Play for sound;
3. downloadable JSON + zip; 4. published with the next label. Verdict, stop.
