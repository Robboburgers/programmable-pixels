# DICTATE — Steps
Operator, 15 August 2026, verbatim:
> "A numpty midi synth would be a nice gizmo - or a synth and a separate
> sequencer - so images and words could drive the sequencer - drive the
> synth."
