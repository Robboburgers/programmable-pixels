# TRIAGE — Glyph
The melt in miniature: any field sampled on a grid, brightness mapped to a
character ramp, the frame returned as words. Deterministic, key-free, runs
in any reader. Ships an `ink` float out-port too (mean coverage) so the
image-become-text can itself drive things — every port that could connect.
Because: an image becomes the characters for it.
