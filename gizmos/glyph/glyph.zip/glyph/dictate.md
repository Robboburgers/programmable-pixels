# DICTATE — Glyph
Operator, 15 August 2026, verbatim:
> "Make a gizmo that makes text from an image."
