# GOAL — Glyph
1. field in, words out, live in the reader; 2. wired to a published image
gizmo on the site, ASCII animating in the lane; 3. downloadable JSON + zip;
4. published with an operator-sequence label. Verdict then stop.
